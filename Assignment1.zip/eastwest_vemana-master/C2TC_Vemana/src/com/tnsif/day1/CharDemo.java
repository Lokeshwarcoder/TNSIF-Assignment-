package com.tnsif.day1;

public class CharDemo {

	public static void main(String[] args) {

		//assigning single character
      char ch ='a';
      System.out.println(ch); //a
      
      //Assigning number to character
      char ch1 =65;
      System.out.println(ch1); //A
      
      //Unicode representation
      char var1= '\u00A7';
      System.out.println(var1);//
      
      //Asci code representation
      int a ='A';
      System.out.println(a); //

	}

}
